#!/usr/bin/env node
/**
 * Publishes the standalone review HTML from the same design sources
 * the React blueprint uses. Writes public/ + artifacts/.
 */
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { OEM_EDGES, OEM_TABLES } from "../src/lib/blueprint/oem-model.ts";
import {
  ORCHESTRATION_RULES,
  ORCHESTRATION_SEQUENCE,
  STAGE_ORCHESTRATION,
  SWARM_AGENTS,
} from "../src/lib/blueprint/orchestration.ts";
import { MATRIX_STAGES, TABLE_MATRIX } from "../src/lib/blueprint/table-matrix.ts";
import { STAGE_FLOWS } from "../src/lib/stage-records.ts";
import { TOC } from "../src/lib/blueprint/toc.ts";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const SRC = join(ROOT, "public/cygnusx-1-blueprint.html");
const existing = readFileSync(SRC, "utf8");

function extract(id) {
  const re = new RegExp(`<section id="${id}">[\\s\\S]*?<\\/section>`);
  const m = existing.match(re);
  if (!m) throw new Error(`section missing: ${id}`);
  return m[0];
}

function setNum(html, n) {
  return html.replace(/<span class="num">\d+<\/span>/, `<span class="num">${n}</span>`);
}

function esc(s) {
  return String(s)
    .replaceAll("&", "&" + "amp;")
    .replaceAll("<", "&" + "lt;")
    .replaceAll(">", "&" + "gt;")
    .replaceAll('"', "&" + "quot;");
}

function table(headers, rows, cls = "") {
  const head = headers.map((h) => `<th>${esc(h)}</th>`).join("");
  const body = rows
    .map(
      (r) =>
        `<tr>${r.map((c) => `<td>${typeof c === "string" ? esc(c) : c}</td>`).join("")}</tr>`,
    )
    .join("\n");
  return `<table${cls ? ` class="${cls}"` : ""}><thead><tr>${head}</tr></thead><tbody>\n${body}\n</tbody></table>`;
}

function verbCell(v) {
  if (!v) return `<td class="ctr muted">·</td>`;
  const kind = v.includes("G") ? "gate" : v.includes("U") ? "update" : v.includes("A") ? "assign" : "create";
  return `<td class="ctr"><span class="verb ${kind}">${esc(v)}</span></td>`;
}

const css = existing.slice(existing.indexOf("<style>"), existing.indexOf("</style>") + 8);
const diagrams = [...existing.matchAll(/<div class="diagram-wrap">[\s\S]*?<\/div>/g)].map((m) => m[0]);
const swarmDiagram =
  diagrams.find((d) => d.includes('aria-label="Agent orchestration"') || d.includes('viewBox="0 0 1040 560"')) ??
  diagrams[0] ??
  "";
const oemDiagram =
  diagrams.find((d) => d.includes('aria-label="Data model"') || d.includes('viewBox="0 0 980 500"')) ??
  diagrams[1] ??
  "";

const matrixRows = TABLE_MATRIX.map((row) => {
  const cells = row.cells.map(verbCell).join("");
  return `<tr><td>${esc(row.table)}</td>${cells}</tr>`;
}).join("\n");

const matrixHead = MATRIX_STAGES.map(
  (s) => `<th class="ctr"><span class="n">${esc(s.id)}</span><br>${esc(s.label)}</th>`,
).join("");

const oemCards = OEM_TABLES.map(
  (t) => `<article class="card" style="padding:1rem 1.1rem">
  <div style="display:flex;justify-content:space-between;gap:.6rem;align-items:baseline">
    <h4 style="margin:0">${esc(t.name)}</h4>
    <span style="font-family:'IBM Plex Mono',monospace;font-size:.68rem;color:var(--gold)">stage ${esc(t.stage)}</span>
  </div>
  <p style="font-size:.82rem;color:var(--ink-soft);margin:.35rem 0 .7rem">${esc(t.purpose)}</p>
  <table style="margin:0"><tbody>
    ${t.columns.map(([c, n]) => `<tr><td style="font-family:'IBM Plex Mono',monospace;font-size:.72rem;color:var(--navy);white-space:nowrap">${esc(c)}</td><td class="muted">${esc(n)}</td></tr>`).join("")}
  </tbody></table>
</article>`,
).join("\n");

const tocHtml = TOC.map((g) => {
  const items = g.items
    .map((s) => `<li><a href="#${s.id}"><span class="n">${s.n}</span> ${esc(s.label)}</a></li>`)
    .join("\n    ");
  return `    <div class="grp">${esc(g.title).toUpperCase()}</div>\n    ${items}`;
}).join("\n");

const overview = setNum(extract("overview"), "01");
const data = setNum(extract("data"), "05");
const mdm = setNum(extract("mdm"), "06");
const rest = [
  ["network", "07"],
  ["tprm", "08"],
  ["dr", "09"],
  ["cyber", "10"],
  ["hallucination", "11"],
  ["eol", "12"],
  ["rtbf", "13"],
  ["crossborder", "14"],
  ["green", "15"],
  ["sla", "16"],
  ["lockin", "17"],
  ["tco", "18"],
  ["ocm", "19"],
  ["training", "20"],
  ["prompts", "21"],
  ["kpi", "22"],
  ["roi", "23"],
  ["glossary", "24"],
]
  .map(([id, n]) => setNum(extract(id), n))
  .join("\n\n");

const oemSection = `<section id="oem">
  <h2><span class="num">02</span> Data Model (OEM)</h2>
  <p class="lede">Canonical tables for CygnusX-1 origination. Process is the aggregate root. Customer and Business are golden records. ApplicantAccount is the borrower login bound to Customer.email. Loan is a 1:1 facility child — created at intake after Business, not as the parent of the file.</p>
  <blockquote class="callout"><strong>camelCase throughout.</strong> Raw SSN/EIN never persist — token plus last four. Consumer CreditPull carries FCRA purpose = this processId. Commercial CreditPull does not. SBSS is not a gate (SOP 50 10 8 / Notice 5000-875701).</blockquote>
  ${oemDiagram}
  <h3>Relationships</h3>
  ${table(["From", "To", "Join"], OEM_EDGES.map((e) => [...e]))}
  <h3>Table catalog</h3>
  ${table(
    ["Table", "PK", "Stage", "Purpose"],
    OEM_TABLES.map((t) => [t.name, t.pk, t.stage, t.purpose]),
  )}
  <h3>Columns by table</h3>
  <div class="grid-2">${oemCards}</div>
</section>`;

const stageSection = `<section id="stageflow">
  <h2><span class="num">03</span> Process Flow & Table Updates</h2>
  <p class="lede">Quote-to-Cash is eight sequential stages. Incomplete work loops inside the stage. A failed gate (consumer credit, commercial credit, OFAC, underwriter reject) closes the process. The matrix shows which canonical table each stage creates, updates, assigns, or gates.</p>
  <blockquote class="callout"><strong>01 Intake —</strong> Customer, email verification + ApplicantAccount, Business, then Loan. <strong>02 Pre-application —</strong> consumer CreditPull, commercial CreditPull, OFAC. RM Elena Voss starts the file; credit and fraud join at 02.</blockquote>
  <h3>What each stage writes</h3>
  ${table(
    ["Stage", "Creates", "Updates / assigns", "Gate"],
    STAGE_ORCHESTRATION.map((s) => [`${s.stage} ${s.name}`, s.creates.join(", "), s.updates.join(", "), s.gate]),
  )}
  <h3>Table update matrix</h3>
  <p>Read across a table to see its lifecycle. Process is created at 01, gated at 02 and 05, and sealed at 08. Loan is created at intake and refined through closure. CreditPull and SanctionsScreen exist only at Pre-application — they are not rewritten later.</p>
  <div class="legend">
    <span class="verb create">C Create row</span>
    <span class="verb update">U Update columns</span>
    <span class="verb assign">A Assign FK / staff / roles</span>
    <span class="verb gate">G Gate on this table</span>
  </div>
  <div class="overflow"><table class="matrix"><thead><tr><th>Table</th>${matrixHead}</tr></thead><tbody>
${matrixRows}
  </tbody></table></div>
  <h3>Records created, assigned, updated</h3>
  <div id="chips" class="chips"></div>
  <div id="stage-panel" class="stage-card"></div>
  <h3>Record map across the file</h3>
  <div class="overflow"><table id="stage-map"></table></div>
</section>`;

const swarmSection = `<section id="swarm">
  <h2><span class="num">04</span> Agent Orchestration Model</h2>
  <p class="lede">A supervisor reads <code>Process.currentStage</code> and dispatches only the workers allowed for that stage. An evaluator reconciles outputs into a package. The stage owner is the human gate. Workers write the canonical tables in Section 03 — they do not keep private copies.</p>
  ${swarmDiagram}
  <h3>Stage → agents → tables</h3>
  ${table(
    ["Stage", "Agents", "Creates", "Updates", "Human", "Gate"],
    STAGE_ORCHESTRATION.map((s) => [
      `${s.stage} ${s.name}`,
      s.agents.join(", "),
      s.creates.join(", "),
      s.updates.join(", "),
      s.human,
      s.gate,
    ]),
  )}
  <h3>Dispatch sequence</h3>
  ${table(
    ["Step", "Actor", "Action"],
    ORCHESTRATION_SEQUENCE.map((s) => [s.step, s.actor, s.action]),
  )}
  <h3>Agent catalog</h3>
  ${table(
    ["Agent", "Kind", "Stage", "Writes", "Human seat"],
    SWARM_AGENTS.map((a) => [a.name, a.kind, a.stage, a.writes.join(", "), a.humanSeat]),
  )}
  <h3>Tool allowlists</h3>
  ${table(
    ["Agent", "Tools"],
    SWARM_AGENTS.map((a) => [a.name, a.tools.join(", ")]),
  )}
  <h3>Orchestration rules</h3>
  <ul>${ORCHESTRATION_RULES.map((r) => `<li>${esc(r)}</li>`).join("")}</ul>
  <blockquote class="callout"><strong>Fail-closed —</strong> consumer credit, commercial credit, and OFAC must pass to leave Pre-application. The swarm cannot infer a pass, invent a guarantyNumber, or post the ledger. Dual-control posting is human.</blockquote>
</section>`;

const stageJson = JSON.stringify(STAGE_FLOWS);

const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CygnusX-1 — SBA Loan Origination Swarm Blueprint</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Serif:wght@400;500;600;700&family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500&display=swap" rel="stylesheet">
${css}
<style>
  .grid-2{display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin:1.3rem 0;}
  @media (max-width: 900px){ .grid-2{grid-template-columns:1fr;} }
</style>
</head>
<body>

<div class="cover">
  <div class="eyebrow-row">
    <span>SBA LENDING · PROJECT BLUEPRINT · CONFIDENTIAL</span>
    <span>CYGNUSX-1 · V1.3 · DOWNLOADABLE HTML</span>
  </div>
  <h1>CygnusX-1 SBA Loan Origination Swarm</h1>
  <p class="subtitle">Data model, process flow with table updates, and agent orchestration for 7(a), Express, and 504. Process is the parent of the file. A human underwriter of record approves every credit decision.</p>
  <div class="btns">
    <a class="btn btn-light" href="#oem">Data model</a>
    <a class="btn btn-ghost" href="#stageflow">Process flow & tables</a>
    <a class="btn btn-ghost" href="#swarm">Agent orchestration</a>
    <a class="btn btn-ghost" href="cygnusx-1-blueprint.html" download="CygnusX-1-Blueprint.html">Download HTML</a>
  </div>
  <div class="meta-grid">
    <div><span class="meta-label">PROGRAMME</span><span class="meta-value">CygnusX-1</span></div>
    <div><span class="meta-label">DOMAIN</span><span class="meta-value">SBA origination</span></div>
    <div><span class="meta-label">AUTONOMY</span><span class="meta-value">L2 at launch → L3 gated</span></div>
    <div><span class="meta-label">SPINE</span><span class="meta-value">processId</span></div>
  </div>
</div>

<div class="layout">
<nav class="toc">
  <div class="toc-title">CONTENTS</div>
  <ol>
${tocHtml}
  </ol>
</nav>

<main>
${overview}

${oemSection}

${stageSection}

${swarmSection}

${data}

${mdm}

${rest}

</main>
</div>

<footer>
  <div class="foot-grid">
    <span>CygnusX-1 — SBA Loan Origination Multi-Agent Swarm Blueprint · V1.3 · HTML review copy</span>
    <span>Confidential — internal review · not legal or regulatory advice</span>
  </div>
</footer>

<script>
const STAGES = ${stageJson};
const verbClass = {create:"create", assign:"assign", update:"update", gate:"gate"};
function render(i){
  const s = STAGES[i];
  document.querySelectorAll(".chip").forEach((c,n)=>c.classList.toggle("on", n===i));
  const recs = s.records.map(r =>
    \`<div class="rec"><div class="rec-h"><span class="verb \${verbClass[r.verb]}">\${r.verb}</span><strong>\${r.record}</strong></div><p style="margin:0;color:var(--ink-soft);font-size:.9rem;">\${r.detail}</p></div>\`
  ).join("");
  document.getElementById("stage-panel").innerHTML =
    \`<p style="font-family:'IBM Plex Mono',monospace;font-size:.72rem;color:var(--gold);letter-spacing:.12em;text-transform:uppercase;margin:0 0 .4rem;">Stage \${s.n} of 08</p>
     <h3 style="margin-top:0;">\${s.name}</h3>
     <p class="lede">\${s.purpose}</p>
     <div class="gatebox"><strong>Gate — </strong>\${s.gate}</div>
     <h4 style="margin-top:0;">Records</h4>\${recs}\`;
}
function map(){
  const rows = STAGES.map((s,i)=>{
    const creates = s.records.filter(r=>r.verb==="create").map(r=>r.record).join(", ") || "—";
    const rest = s.records.filter(r=>r.verb!=="create").map(r=>r.record).join(", ") || "—";
    return \`<tr><td><a href="#stageflow" data-i="\${i}">\${s.n} \${s.name}</a></td><td>\${creates}</td><td>\${rest}</td></tr>\`;
  }).join("");
  document.getElementById("stage-map").innerHTML =
    \`<thead><tr><th>Stage</th><th>Creates</th><th>Assigns / updates</th></tr></thead><tbody>\${rows}</tbody>\`;
  document.getElementById("stage-map").addEventListener("click", e=>{
    const a = e.target.closest("a[data-i]");
    if(a){ e.preventDefault(); render(+a.dataset.i); }
  });
}
document.getElementById("chips").innerHTML = STAGES.map((s,i)=>
  \`<button type="button" class="chip\${i===0?" on":""}" data-i="\${i}"><span class="n">\${s.n}</span>\${s.name}</button>\`
).join("");
document.getElementById("chips").addEventListener("click", e=>{
  const b = e.target.closest("button[data-i]");
  if(b) render(+b.dataset.i);
});
map();
render(0);
</script>
</body>
</html>
`;

const outPublic = join(ROOT, "public/cygnusx-1-blueprint.html");
const outArt = join(ROOT, "artifacts/CygnusX-1-Blueprint.html");
mkdirSync(join(ROOT, "artifacts"), { recursive: true });
const published = html.replace("a stage in Section 23.", "a stage in Section 03.");
writeFileSync(outPublic, published);
writeFileSync(outArt, published);
console.log("published", outPublic, published.length, "bytes");
console.log("published", outArt);
