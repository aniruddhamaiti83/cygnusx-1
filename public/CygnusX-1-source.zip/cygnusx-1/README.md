# CygnusX-1

SBA Quote-to-Cash origination: Customer → verify/account → Business → Loan →
Pre-application (consumer + commercial credit) → Processing → Collateral →
Underwriter (multi-agent swarm) → Documents → Financing → Closure.

Process ID is the parent. OEM is 25 tables. CamelCase fields. No third-party
origination brand names.

## Push this folder to GitHub (then open in VS Code)

This sandbox cannot authenticate to your GitHub account. Publish from your
machine:

### Fast path — GitHub CLI

```bash
unzip CygnusX-1-source.zip
cd cygnusx-1
git init -b main
git add .
git commit -m "Initial commit: CygnusX-1 origination and Phase 2 swarm"
gh repo create cygnusx-1 --private --source=. --remote=origin --push
```

Then in VS Code: **Command Palette → Git: Clone** and paste the repo URL.

### VS Code only (no CLI)

1. Unzip `CygnusX-1-source.zip` and **File → Open Folder**.
2. Source Control → **Initialize Repository**.
3. Commit, then **Publish to GitHub** (private recommended).
4. After that, clone anywhere with **Git: Clone**.

Later clones:

```bash
git clone https://github.com/<you>/cygnusx-1.git
code cygnusx-1
```

## Local stack

| Layer | Location | Port |
| --- | --- | --- |
| Frontend | React + Vite (`src/`) | 8080 |
| API | FastAPI (`backend/`) | 8000 |
| Database | PostgreSQL, or SQLite if `DATABASE_URL` is unset | — |
| Agents | LangChain supervisor + stage workers | — |

### 1. Database

```bash
createdb cygnusx1
export DATABASE_URL=postgresql://USER:PASS@localhost:5432/cygnusx1
```

### 2. Local LLM (optional)

```bash
export LLM_BASE_URL=http://127.0.0.1:11434/v1
export LLM_API_KEY=ollama
export LLM_MODEL=llama3.1
```

If `LLM_BASE_URL` is empty, the swarm uses xAI when `XAI_API_KEY` is set,
otherwise a deterministic heuristic so origination still runs.

### 3. Python API

```bash
cd backend
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

### 4. Frontend

```bash
npm install
npm run dev
```

`/api/cx1` is proxied to FastAPI. Origination writes PostgreSQL tables. Stage
buttons dispatch LangChain workers that persist `CreditPull`, `SanctionsScreen`,
`KybReport`, `ScorecardResult`, and `AgentEvent`. The underwriter scorecard
recommends; the human of record decides.

## Blueprint

Standalone review copy: [`public/cygnusx-1-blueprint.html`](public/cygnusx-1-blueprint.html)

Design sections at the front:

1. Data model (OEM)
2. Process flow with tables updated
3. Agent orchestration (supervisor → stage workers → evaluator)

Phase 2 in-app: Collateral + Underwriter multi-agent stage.
